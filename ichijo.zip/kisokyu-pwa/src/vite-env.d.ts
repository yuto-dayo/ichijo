/// <reference types="vite/client" />
/// <reference path="./pwa-env.d.ts" />
